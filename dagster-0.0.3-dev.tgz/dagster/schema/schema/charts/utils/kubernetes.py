from enum import Enum
from typing import Any

from pydantic import BaseModel, RootModel

from schema.charts.utils.utils import (
    BaseModel as BaseModelWithNullableRequiredFields,
    create_definition_ref,
)


class Annotations(RootModel[dict[str, str]]):
    model_config = {
        "json_schema_extra": {
            "$ref": create_definition_ref(
                "io.k8s.apimachinery.pkg.apis.meta.v1.ObjectMeta/properties/annotations"
            )
        }
    }


class Labels(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {
            "$ref": create_definition_ref(
                "io.k8s.apimachinery.pkg.apis.meta.v1.ObjectMeta/properties/labels"
            )
        },
    }


class PullPolicy(str, Enum):
    ALWAYS = "Always"
    IF_NOT_PRESENT = "IfNotPresent"
    NEVER = "Never"


class Image(BaseModelWithNullableRequiredFields):
    repository: str
    tag: str | int | None = None
    digest: str | None = None
    pullPolicy: PullPolicy

    @property
    def name(self) -> str:
        if self.digest:
            return f"{self.repository}@{self.digest}"
        elif self.tag:
            return f"{self.repository}:{self.tag}"
        else:
            return self.repository


class ExternalImage(Image):
    tag: str


class InitContainerImage(BaseModel):
    """Image specification for init containers, with all fields optional except repository."""

    repository: str
    tag: str | int | None = None
    digest: str | None = None
    pullPolicy: PullPolicy | None = None

    @property
    def name(self) -> str:
        if self.digest:
            return f"{self.repository}@{self.digest}"
        elif self.tag:
            return f"{self.repository}:{self.tag}"
        else:
            return self.repository


class Service(BaseModel, extra="forbid"):
    type: str
    port: int
    annotations: Annotations | None = None


class NodeSelector(RootModel[dict[str, str]]):
    model_config = {
        "json_schema_extra": {
            "extra": "allow",
            "$ref": create_definition_ref("io.k8s.api.core.v1.PodSpec/properties/nodeSelector"),
        }
    }


class Affinity(RootModel[dict[str, Any]]):
    model_config = {
        "json_schema_extra": {
            "$ref": create_definition_ref("io.k8s.api.core.v1.Affinity"),
            "additionalProperties": True,
        }
    }


def _tolerations_schema_extra(schema: dict[str, Any], _model: type["Tolerations"]) -> None:
    schema.setdefault(
        "$ref",
        create_definition_ref("io.k8s.api.core.v1.PodSpec/properties/tolerations"),
    )
    if "items" in schema:
        schema["items"]["additionalProperties"] = True


class Tolerations(RootModel[list[dict[str, Any]]]):
    model_config = {"json_schema_extra": _tolerations_schema_extra}


class PodSecurityContext(RootModel[dict[str, Any]]):
    model_config = {
        "json_schema_extra": {
            "$ref": create_definition_ref("io.k8s.api.core.v1.PodSecurityContext"),
            "additionalProperties": True,
        }
    }


class SecurityContext(
    RootModel[dict[str, Any]],
    json_schema_extra={
        "$ref": create_definition_ref("io.k8s.api.core.v1.SecurityContext"),
        "additionalProperties": True,
    },
):
    pass


class InitContainer(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {"$ref": create_definition_ref("io.k8s.api.core.v1.Container")},
    }


class InitContainerWithStructuredImage(BaseModel):
    """Init container with structured image specification (repository/tag/digest)."""

    name: str
    image: InitContainerImage

    model_config = {
        "extra": "allow",
    }


class Resources(RootModel[dict[str, Any]]):
    model_config = {
        "json_schema_extra": {
            "$ref": create_definition_ref("io.k8s.api.core.v1.ResourceRequirements"),
            "additionalProperties": True,
        }
    }


class LivenessProbe(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {"$ref": create_definition_ref("io.k8s.api.core.v1.Probe")},
    }


class ReadinessProbe(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {"$ref": create_definition_ref("io.k8s.api.core.v1.Probe")},
    }


class StartupProbe(BaseModel):
    enabled: bool = True

    model_config = {
        "extra": "allow",
        "json_schema_extra": {
            "$ref": create_definition_ref("io.k8s.api.core.v1.Probe"),
        },
    }


class SecretRef(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {
            "$ref": create_definition_ref("io.k8s.api.core.v1.LocalObjectReference")
        },
    }


class SecretEnvSource(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {"$ref": create_definition_ref("io.k8s.api.core.v1.SecretEnvSource")},
    }


class ConfigMapEnvSource(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {
            "$ref": create_definition_ref("io.k8s.api.core.v1.ConfigMapEnvSource")
        },
    }


class VolumeMount(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {"$ref": create_definition_ref("io.k8s.api.core.v1.VolumeMount")},
    }


class Volume(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {"$ref": create_definition_ref("io.k8s.api.core.v1.Volume")},
    }


class ResourceRequirements(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {
            "$ref": create_definition_ref("io.k8s.api.core.v1.ResourceRequirements")
        },
    }


class EnvVar(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {"$ref": create_definition_ref("io.k8s.api.core.v1.EnvVar")},
    }


class Container(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {"$ref": create_definition_ref("io.k8s.api.core.v1.Container")},
    }


class DeploymentStrategy(BaseModel):
    model_config = {
        "extra": "allow",
        "json_schema_extra": {
            "$ref": create_definition_ref("io.k8s.api.apps.v1.DeploymentStrategy")
        },
    }
