import json
import os
import re
import shutil
import subprocess
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from pprint import pprint
from tempfile import NamedTemporaryFile, mkstemp
from typing import Any

import dagster._check as check
import yaml
from dagster._utils import discover_oss_root
from dagster_shared.yaml_utils import safe_load_yaml
from kubernetes.client.api_client import ApiClient

from schema.charts.dagster.values import DagsterHelmValues
from schema.charts.dagster_user_deployments.values import DagsterUserDeploymentsHelmValues


def git_repo_root():
    return subprocess.check_output(["git", "rev-parse", "--show-toplevel"]).decode("utf-8").strip()


_HELM_SCHEMA_FETCH_FAILURE_RE = re.compile(r'failing loading "https?://')


def _run_helm_template(command: list[str], max_attempts: int = 3, delay: float = 2.0) -> bytes:
    # Retry only when helm's schema loader fails to fetch a $ref URL
    # (any host, any HTTP error). Helm formats these as: failing loading "<url>": <err>
    for attempt in range(1, max_attempts + 1):
        try:
            return subprocess.run(command, capture_output=True, check=True).stdout
        except subprocess.CalledProcessError as e:
            stderr_text = e.stderr.decode("utf-8", errors="replace")
            if _HELM_SCHEMA_FETCH_FAILURE_RE.search(stderr_text) and attempt < max_attempts:
                time.sleep(delay)
                continue
            sys.stderr.write(stderr_text)
            raise
    raise AssertionError("unreachable")


@dataclass
class HelmTemplate:
    helm_dir_path: str
    subchart_paths: list[str]
    output: str | None = None
    model: Any | None = None
    release_name: str = "release-name"
    api_client: ApiClient = ApiClient()  # noqa: RUF009
    namespace: str = "default"

    def render(
        self,
        values: DagsterHelmValues | DagsterUserDeploymentsHelmValues | None = None,
        values_dict: dict[str, Any] | None = None,
        chart_version: str | None = None,
    ) -> list[Any]:
        check.invariant(
            (values is None) != (values_dict is None), "Must provide either values or values_dict"
        )

        with NamedTemporaryFile() as tmp_file:
            if os.path.isabs(self.helm_dir_path):
                helm_dir_path = self.helm_dir_path
            else:
                helm_dir_path = os.path.join(discover_oss_root(Path(__file__)), self.helm_dir_path)

            values_json = (
                json.loads(values.model_dump_json(exclude_none=True, by_alias=True))
                if values
                else values_dict
            )
            pprint(values_json)  # noqa: T203
            content = yaml.dump(values_json)
            tmp_file.write(content.encode())
            tmp_file.flush()

            command = [
                "helm",
                "template",
                self.release_name,
                helm_dir_path,
                "--debug",
                "--namespace",
                self.namespace,
                "--values",
                tmp_file.name,
            ]

            with self._with_chart_yaml(helm_dir_path, chart_version):
                templates = _run_helm_template(command)

                # HACK! Helm's --show-only option doesn't surface errors. For tests where we want to
                # assert on things like {{ fail ... }}, we need to render the chart without --show-only.
                # If that succeeds, we then carry on to calling with --show-only so that we can
                # assert on specific objects in the chart.
                if self.output:
                    command += ["--show-only", self.output]
                    templates = _run_helm_template(command)

            print("\n--- Helm Templates ---")  # noqa: T201
            print(templates.decode())  # noqa: T201

            k8s_objects = [k8s_object for k8s_object in yaml.full_load_all(templates) if k8s_object]
            if self.model:
                k8s_objects = [
                    self.api_client._ApiClient__deserialize_model(  # noqa: SLF001
                        k8s_object,
                        self.model,
                    )
                    for k8s_object in k8s_objects
                ]

            return k8s_objects

    @contextmanager
    def _with_chart_yaml(self, helm_dir_path: str, chart_version: str | None):
        if not chart_version:
            yield
        else:
            umbrella_chart_path = os.path.join(helm_dir_path, "Chart.yaml")
            subchart_chart_paths = [
                os.path.join(helm_dir_path, subchart_path, "Chart.yaml")
                for subchart_path in self.subchart_paths
            ]

            chart_paths = subchart_chart_paths + [umbrella_chart_path]
            chart_copy_paths = []
            for chart_path in chart_paths:
                _, chart_copy_path = mkstemp()
                shutil.copy2(chart_path, chart_copy_path)
                chart_copy_paths.append(chart_copy_path)

                with open(chart_path, encoding="utf8") as chart_file:
                    old_chart_yaml = safe_load_yaml(chart_file)

                with open(chart_path, "w", encoding="utf8") as chart_file:
                    new_chart_yaml = old_chart_yaml.copy()
                    new_chart_yaml["version"] = chart_version
                    yaml.dump(new_chart_yaml, chart_file)

            yield

            for chart_path, chart_copy_path in zip(chart_paths, chart_copy_paths):
                shutil.copy2(chart_copy_path, chart_path)
                os.remove(chart_copy_path)
